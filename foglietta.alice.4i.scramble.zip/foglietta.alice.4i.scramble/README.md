# Peso Lettere

Chi ha giocato a “Scarabeo” saprà che le parole hanno un peso.

Questo esercizio si basa sul calcolo di questo peso.

Ogni lettera vale un punteggio secondo questa tabella

| Lettera | Valore | 
|--|--|
| a, e, i, o, u, l, n, r, s, t | valgono 1 |
| d, g | valgono 2  |
| b, c, m, p | valgono 3 |
| f, h, v, w, y | valgono 4 |
| k | vale 5 |
| j, x | valgono 8 | 
| q, z | valgono 10 |

La parola “ciao” quindi vale 3 + 1 + 1 + 1 = **6**
